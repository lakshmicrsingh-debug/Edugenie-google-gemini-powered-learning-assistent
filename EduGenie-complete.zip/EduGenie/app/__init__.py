"""EduGenie application package."""
